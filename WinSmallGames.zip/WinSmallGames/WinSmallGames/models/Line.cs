﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinSmallGames.models
{
    public class Line
    {
        public Toothpick toothpick { get; set; }
        public int count { get; set; }
        public int selected { get; set; }
    }
}
